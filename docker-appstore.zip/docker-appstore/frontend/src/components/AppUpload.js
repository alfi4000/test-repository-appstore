import React, { useState } from 'react';
import axios from 'axios';

function AppUpload() {
  const [formData, setFormData] = useState({
    name: '',
    packageName: '',
    version: '',
    description: '',
  });
  const [apkFile, setApkFile] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    data.append('apk', apkFile);
    Object.keys(formData).forEach(key => {
      data.append(key, formData[key]);
    });

    try {
      await axios.post('http://localhost:3033/api/apps', data, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      alert('App uploaded successfully!');
    } catch (error) {
      console.error('Error uploading app:', error);
      alert('Error uploading app');
    }
  };

  return (
    <div className="app-upload">
      <h2>Upload New App</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            required
          />
        </div>
        <div>
          <label>Package Name:</label>
          <input
            type="text"
            value={formData.packageName}
            onChange={(e) => setFormData({...formData, packageName: e.target.value})}
            required
          />
        </div>
        <div>
          <label>Version:</label>
          <input
            type="text"
            value={formData.version}
            onChange={(e) => setFormData({...formData, version: e.target.value})}
            required
          />
        </div>
        <div>
          <label>Description:</label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
          />
        </div>
        <div>
          <label>APK File:</label>
          <input
            type="file"
            accept=".apk"
            onChange={(e) => setApkFile(e.target.files[0])}
            required
          />
        </div>
        <button type="submit">Upload</button>
      </form>
    </div>
  );
}

export default AppUpload; 