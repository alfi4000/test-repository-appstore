import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AppList() {
  const [apps, setApps] = useState([]);

  useEffect(() => {
    const fetchApps = async () => {
      try {
        const response = await axios.get('http://localhost:3033/api/apps');
        setApps(response.data);
      } catch (error) {
        console.error('Error fetching apps:', error);
      }
    };

    fetchApps();
  }, []);

  const handleDownload = async (id) => {
    try {
      window.open(`http://localhost:3033/api/apps/download/${id}`, '_blank');
    } catch (error) {
      console.error('Error downloading app:', error);
    }
  };

  return (
    <div className="app-list">
      <h2>Available Apps</h2>
      {apps.map((app) => (
        <div key={app._id} className="app-item">
          <h3>{app.name}</h3>
          <p>Version: {app.version}</p>
          <p>{app.description}</p>
          <button onClick={() => handleDownload(app._id)}>Download</button>
        </div>
      ))}
    </div>
  );
}

export default AppList; 