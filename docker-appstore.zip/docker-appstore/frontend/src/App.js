import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AppList from './components/AppList';
import AppUpload from './components/AppUpload';

function App() {
  return (
    <Router>
      <div className="App">
        <header>
          <h1>Android App Store</h1>
        </header>
        <main>
          <Routes>
            <Route path="/" element={<AppList />} />
            <Route path="/upload" element={<AppUpload />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App; 