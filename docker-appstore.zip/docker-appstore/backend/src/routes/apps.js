const express = require('express');
const router = express.Router();
const App = require('../models/App');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

const upload = multer({ storage });

// Get all apps
router.get('/', async (req, res) => {
  try {
    const apps = await App.find();
    res.json(apps);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Upload new app
router.post('/', upload.single('apk'), async (req, res) => {
  const app = new App({
    name: req.body.name,
    packageName: req.body.packageName,
    version: req.body.version,
    description: req.body.description,
    apkFile: req.file.path
  });

  try {
    const newApp = await app.save();
    res.status(201).json(newApp);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Download app
router.get('/download/:id', async (req, res) => {
  try {
    const app = await App.findById(req.params.id);
    if (!app) {
      return res.status(404).json({ message: 'App not found' });
    }
    res.download(app.apkFile);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router; 