const mongoose = require('mongoose');

const AppSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  packageName: {
    type: String,
    required: true,
    unique: true
  },
  version: {
    type: String,
    required: true
  },
  description: String,
  icon: String,
  apkFile: {
    type: String,
    required: true
  },
  downloads: {
    type: Number,
    default: 0
  },
  uploadDate: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('App', AppSchema); 